const API =
"http://localhost:3000";


// =========================
// USUARIO
// =========================

const usuario =
JSON.parse(
    localStorage.getItem(
        "usuario"
    )
);


// =========================
// CARRITO
// =========================

let carrito =
JSON.parse(
    localStorage.getItem(
        "carrito"
    )
) || [];


// =========================
// NAVBAR
// =========================

function cargarNavbar(){

    const nav =
    document.getElementById(
        "navButtons"
    );

    // ADMIN
    if(
        usuario &&
        usuario.rol === "admin"
    ){

        nav.innerHTML = `

        <a href="admin.html">

            <button>

                Administrador

            </button>

        </a>

        <a href="inventario.html">

            <button>

                Inventario

            </button>

        </a>

        <a href="perfil.html">

            <button>

                Perfil

            </button>

        </a>

        <button onclick="cerrarSesion()">

            Cerrar Sesión

        </button>

        `;

    }

    // USER
    else{

        nav.innerHTML = `

        <a href="perfil.html">

            <button>

                Mi Perfil

            </button>

        </a>

        <button onclick="cerrarSesion()">

            Cerrar Sesión

        </button>

        `;

    }

}


// =========================
// CARGAR PRODUCTOS
// =========================

async function cargarProductos(){

    try{

        const respuesta =
        await fetch(
            `${API}/productos`
        );

        const productos =
        await respuesta.json();

        const contenedor =
        document.getElementById(
            "productos"
        );

        contenedor.innerHTML = "";

        productos.forEach(producto=>{

            // CONVERTIR PRECIO
            const precio =
            Number(producto.precio);

            contenedor.innerHTML += `

            <div class="card">

                <img
                src="${producto.imagen}"
                alt="${producto.nombre}">

                <div class="card-content">

                    <h3>

                    ${producto.nombre}

                    </h3>

                    <p>

                    Categoría:
                    ${producto.categoria}

                    </p>

                    <p>

                    Precio:
                    Q${precio.toFixed(2)}

                    </p>

                    <p>

                    Disponibles:
                    ${producto.cantidad}

                    </p>

                    <button
                    onclick="agregarCarrito(
                        ${producto.id},
                        '${producto.nombre}',
                        ${precio}
                    )">

                        Agregar al carrito

                    </button>

                </div>

            </div>

            `;
        });

    }catch(error){

        console.log(error);

        alert(
            "Error cargando productos"
        );

    }

}


// =========================
// AGREGAR CARRITO
// =========================

function agregarCarrito(
    id,
    nombre,
    precio
){

    carrito.push({

        id,
        nombre,
        precio:Number(precio)

    });

    // GUARDAR
    localStorage.setItem(

        "carrito",

        JSON.stringify(carrito)

    );

    actualizarCarrito();

    alert(
        "Producto agregado al carrito"
    );

}


// =========================
// ACTUALIZAR CARRITO
// =========================

function actualizarCarrito(){

    const carritoHTML =
    document.getElementById(
        "carrito"
    );

    carritoHTML.innerHTML = "";

    let total = 0;


    // VACIO
    if(carrito.length === 0){

        carritoHTML.innerHTML = `

        <p>

        Carrito vacío

        </p>

        `;

        return;

    }


    carrito.forEach((producto,index)=>{

        const precio =
        Number(producto.precio);

        total += precio;

        carritoHTML.innerHTML += `

        <div class="carrito-item">

            <div>

                <h4>

                ${producto.nombre}

                </h4>

                <p>

                Q${precio.toFixed(2)}

                </p>

            </div>

            <button
            onclick="eliminarDelCarrito(${index})">

                X

            </button>

        </div>

        `;

    });


    carritoHTML.innerHTML += `

    <hr>

    <h2>

    Total:
    Q${total.toFixed(2)}

    </h2>

    <button onclick="vaciarCarrito()">

        Vaciar carrito

    </button>

    `;

}


// =========================
// VACIAR
// =========================

function vaciarCarrito(){

    carrito = [];

    localStorage.removeItem(
        "carrito"
    );

    actualizarCarrito();

}

function eliminarDelCarrito(index){

    carrito.splice(index,1);

    localStorage.setItem(

        "carrito",

        JSON.stringify(carrito)

    );

    actualizarCarrito();

}

// =========================
// CERRAR SESION
// =========================

function cerrarSesion(){

    localStorage.removeItem(
        "usuario"
    );

    localStorage.removeItem(
        "token"
    );

    window.location.href =
    "login.html";

}


// =========================
// INICIAR
// =========================

cargarNavbar();

cargarProductos();

actualizarCarrito();