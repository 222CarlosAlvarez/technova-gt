const API =
"http://localhost:3000";


// =========================
// LOGIN
// =========================

async function login(){

    const correo =
    document.getElementById("correo")
    .value;

    const password =
    document.getElementById("password")
    .value;


    // VALIDAR
    if(!correo || !password){

        alert(
            "Completa todos los campos"
        );

        return;
    }

    try{

        const respuesta =
        await fetch(

            `${API}/login`,

            {

                method:"POST",

                headers:{
                    "Content-Type":
                    "application/json"
                },

                body:JSON.stringify({

                    correo,
                    password

                })

            }

        );

        const datos =
        await respuesta.json();

        // ERROR
        if(!respuesta.ok){

            alert(

                datos.mensaje
                ||
                "Error al iniciar sesión"

            );

            return;
        }

        // GUARDAR TOKEN
        localStorage.setItem(

            "token",

            datos.token

        );

        // GUARDAR USUARIO
        localStorage.setItem(

            "usuario",

            JSON.stringify(
                datos.usuario
            )

        );

        alert(
            "Bienvenido"
        );

        // ADMIN
        if(datos.usuario.rol === "admin"){

            window.location.href =
            "admin.html";

        }else{

            window.location.href =
            "tienda.html";

        }

    }catch(error){

        console.log(error);

        alert(
            "No se pudo conectar al servidor"
        );

    }

}