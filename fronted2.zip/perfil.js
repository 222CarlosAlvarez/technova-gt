const usuario =
JSON.parse(
    localStorage.getItem("usuario")
);

// VERIFICAR LOGIN
if(!usuario){

    window.location.href =
    "login.html";
}


// =========================
// MOSTRAR PERFIL
// =========================

// FOTO
document.getElementById(
    "fotoPerfil"
).src =
usuario.foto ||
"https://i.imgur.com/6VBx3io.png";


// NOMBRE
document.getElementById(
    "nombre"
).innerHTML =
usuario.nombre;


// CORREO
document.getElementById(
    "correo"
).innerHTML =
usuario.correo;


// ROL
document.getElementById(
    "rol"
).innerHTML =
"Rol: " + usuario.rol;


// =========================
// CARGAR HISTORIAL
// =========================

async function cargarHistorial(){

    try{

        const respuesta =
        await fetch(

            `http://localhost:3000/compras/${usuario.id}`

        );

        const compras =
        await respuesta.json();

        console.log(compras);

        const contenedor =
        document.getElementById(
            "historial"
        );

        contenedor.innerHTML = "";

        // SI NO HAY COMPRAS
        if(compras.length === 0){

            contenedor.innerHTML = `

            <h2 style="padding:20px;">

                No hay compras realizadas

            </h2>

            `;

            return;
        }

        // RECORRER COMPRAS
        compras.forEach(compra=>{

            contenedor.innerHTML += `

            <div class="card">

                <div class="card-content">

                    <h3>

                    Compra #${compra.id}

                    </h3>

                    <p>

                    Total:
                    Q${Number(compra.total)
                    .toFixed(2)}

                    </p>

                    <p>

                    Fecha:
                    ${compra.fecha}

                    </p>

                </div>

            </div>

            `;
        });

    }catch(error){

        console.log(error);

    }

}


// =========================
// INICIAR
// =========================

cargarHistorial();

// =========================
// CERRAR SESION
// =========================

function logout(){

    localStorage.removeItem(
        "usuario"
    );

    localStorage.removeItem(
        "token"
    );

    localStorage.removeItem(
        "carrito"
    );

    window.location.href =
    "login.html";
}