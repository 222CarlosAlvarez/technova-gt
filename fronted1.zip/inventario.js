const API =
"http://localhost:3000";

let productosGlobal = [];


// =========================
// CARGAR INVENTARIO
// =========================

async function cargarInventario(){

    const respuesta =
    await fetch(
        `${API}/productos`
    );

    const productos =
    await respuesta.json();

    productosGlobal =
    productos;

    renderProductos(productos);

}


// =========================
// RENDER
// =========================

function renderProductos(productos){

    const contenedor =
    document.getElementById(
        "inventario"
    );

    contenedor.innerHTML = "";

    productos.forEach(producto=>{

        contenedor.innerHTML += `

        <div class="card">

            <img
            src="${producto.imagen}">

            <div class="card-content">

                <h3>

                ${producto.nombre}

                </h3>

                <p>

                Categoría:
                ${producto.categoria}

                </p>

                <p>

                Precio:
                Q${producto.precio}

                </p>

                <p>

                Stock:
                ${producto.cantidad}

                </p>

                <button
                onclick="eliminarProducto(${producto.id})">

                    Eliminar

                </button>

            </div>

        </div>

        `;
    });

}


// =========================
// BUSCAR
// =========================

function buscarCategoria(){

    const texto =
    document.getElementById(
        "buscarCategoria"
    ).value.toLowerCase();

    const filtrados =
    productosGlobal.filter(producto=>

        producto.categoria
        .toLowerCase()
        .includes(texto)

    );

    renderProductos(filtrados);

}


// =========================
// AGREGAR PRODUCTO
// =========================

async function agregarProducto(){

    const nombre =
    document.getElementById("nombre")
    .value;

    const precio =
    document.getElementById("precio")
    .value;

    const cantidad =
    document.getElementById("cantidad")
    .value;

    const categoria =
    document.getElementById("categoria")
    .value;

    const imagen =
    document.getElementById("imagen")
    .value;


    await fetch(

        `${API}/productos`,

        {

            method:"POST",

            headers:{
                "Content-Type":
                "application/json"
            },

            body:JSON.stringify({

                nombre,
                precio,
                cantidad,
                categoria,
                imagen

            })

        }

    );

    alert(
        "Producto agregado"
    );

    cargarInventario();

}


// =========================
// ELIMINAR
// =========================

async function eliminarProducto(id){

    await fetch(

        `${API}/productos/${id}`,

        {

            method:"DELETE"

        }

    );

    cargarInventario();

}


// INICIAR
cargarInventario();