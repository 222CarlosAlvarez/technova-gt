const API =
"http://localhost:3000/productos";


// CARGAR PRODUCTOS
async function cargarProductos(){

    const respuesta =
    await fetch(API);

    const productos =
    await respuesta.json();

    dashboard(productos);

    const contenedor =
    document.getElementById("productos");

    contenedor.innerHTML = "";

    productos.forEach(producto=>{

        contenedor.innerHTML += `

        <div class="card">

            <img
            src="${producto.imagen}">

            <div class="card-content">

                <h3>${producto.nombre}</h3>

                <p>${producto.categoria}</p>

                <p>Q${producto.precio}</p>

                <button
                onclick="eliminar(${producto.id})">

                    Eliminar

                </button>

            </div>

        </div>
        `;
    });

}


// DASHBOARD
function dashboard(productos){

    document.getElementById(
        "totalProductos"
    ).innerHTML =
    productos.length;

    const categorias =
    [...new Set(
        productos.map(
            p=>p.categoria
        )
    )];

    document.getElementById(
        "totalCategorias"
    ).innerHTML =
    categorias.length;
}


// AGREGAR PRODUCTO
async function agregarProducto(){

    const producto = {

        nombre:
        document.getElementById("nombre").value,

        categoria:
        document.getElementById("categoria").value,

        precio:
        document.getElementById("precio").value,

        cantidad:
        document.getElementById("cantidad").value,

        imagen:
        document.getElementById("imagen").value
    };

    await fetch(API,{

        method:"POST",

        headers:{
            "Content-Type":"application/json"
        },

        body:JSON.stringify(producto)
    });

    alert("Producto agregado");

    cargarProductos();
}


// ELIMINAR
async function eliminar(id){

    await fetch(
        `${API}/${id}`,
        {
            method:"DELETE"
        }
    );

    cargarProductos();
}

cargarProductos();

async function estadisticas(){

    const respuesta =
    await fetch(
        "http://localhost:3000/estadisticas"
    );

    const datos =
    await respuesta.json();

    document.getElementById(
        "ventasTotales"
    ).innerHTML =

    `Q${datos.ventas}`;

    document.getElementById(
        "usuariosTotales"
    ).innerHTML =

    datos.usuarios;
}

estadisticas();