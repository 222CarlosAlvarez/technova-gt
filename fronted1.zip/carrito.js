const API =
"http://localhost:3000/productos";

const usuario =
JSON.parse(
    localStorage.getItem("usuario")
);

// VERIFICAR LOGIN
if(!usuario){

    window.location.href =
    "login.html";
}


// =========================
// CARGAR CARRITO
// =========================

async function cargarCarrito(){

    try{

        const respuesta =
        await fetch(API);

        const productos =
        await respuesta.json();

        // OBTENER CARRITO
        const carrito =
        JSON.parse(
            localStorage.getItem("carrito")
        ) || [];

        const contenedor =
        document.getElementById("carrito");

        contenedor.innerHTML = "";

        // SI NO HAY PRODUCTOS
        if(carrito.length === 0){

            contenedor.innerHTML = `

            <h2 style="padding:20px;">

                Tu carrito está vacío

            </h2>

            `;

            document.getElementById(
                "subtotal"
            ).innerHTML = "Q0";

            document.getElementById(
                "iva"
            ).innerHTML = "Q0";

            document.getElementById(
                "total"
            ).innerHTML = "Q0";

            return;
        }

        let subtotal = 0;

        // RECORRER CARRITO
        carrito.forEach(item=>{

            // BUSCAR PRODUCTO
            const producto =
            productos.find(
                p => Number(p.id) === Number(item.id)
            );

            // SI EXISTE
            if(producto){

                const totalProducto =

                Number(producto.precio) *
                Number(item.cantidad);

                subtotal += totalProducto;

                contenedor.innerHTML += `

                <div class="card-checkout">

                    <img
                    src="${producto.imagen}">

                    <div class="checkout-info">

                        <h3>
                        ${producto.nombre}
                        </h3>

                        <p>
                        ${producto.categoria}
                        </p>

                        <p>
                        Precio:
                        Q${producto.precio}
                        </p>

                        <p>
                        Cantidad:
                        ${item.cantidad}
                        </p>

                        <h4>

                        Total:
                        Q${totalProducto.toFixed(2)}

                        </h4>

                        <button
                        onclick="eliminar(${item.id})">

                            Eliminar

                        </button>

                    </div>

                </div>
                `;
            }

        });

        // IVA
        const iva =
        subtotal * 0.12;

        // TOTAL
        const total =
        subtotal + iva;

        // MOSTRAR
        document.getElementById(
            "subtotal"
        ).innerHTML =
        `Q${subtotal.toFixed(2)}`;

        document.getElementById(
            "iva"
        ).innerHTML =
        `Q${iva.toFixed(2)}`;

        document.getElementById(
            "total"
        ).innerHTML =
        `Q${total.toFixed(2)}`;

    }catch(error){

        console.log(error);

    }

}


// =========================
// ELIMINAR PRODUCTO
// =========================

function eliminar(id){

    let carrito =

    JSON.parse(
        localStorage.getItem("carrito")
    ) || [];

    carrito = carrito.filter(

        item => Number(item.id)
        !== Number(id)

    );

    localStorage.setItem(

        "carrito",

        JSON.stringify(carrito)
    );

    cargarCarrito();
}


// =========================
// FINALIZAR COMPRA
// =========================

async function comprar(){

    const carrito =
    JSON.parse(
        localStorage.getItem("carrito")
    ) || [];

    if(carrito.length === 0){

        alert("Carrito vacío");

        return;
    }

    try{

        const respuesta =
        await fetch(API);

        const productos =
        await respuesta.json();

        let subtotal = 0;

        carrito.forEach(item=>{

            const producto =
            productos.find(
                p=>Number(p.id)
                === Number(item.id)
            );

            if(producto){

                subtotal +=

                Number(producto.precio) *

                Number(item.cantidad);
            }

        });

        // IVA GUATEMALA
        const iva =
        subtotal * 0.12;

        // TOTAL
        const total =
        subtotal + iva;

        // GUARDAR COMPRA
        const guardar =
        await fetch(
            "http://localhost:3000/compras",
            {

                method:"POST",

                headers:{
                    "Content-Type":
                    "application/json"
                },

                body:JSON.stringify({

                    usuario_id:
                    usuario.id,

                    total:
                    total,

                    fecha:
                    new Date()
                    .toLocaleString()

                })

            }
        );

        const resultado =
        await guardar.json();

        console.log(resultado);

        alert(`

Compra realizada correctamente

TOTAL:
Q${total.toFixed(2)}

`);

        // LIMPIAR CARRITO
        localStorage.removeItem(
            "carrito"
        );

        // RECARGAR
        cargarCarrito();

    }catch(error){

        console.log(error);

    }

}

// =========================
// INICIAR
// =========================

cargarCarrito();