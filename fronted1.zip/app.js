const API = "http://localhost:3000/productos";

async function cargarProductos(){

    const respuesta = await fetch(API);

    const productos = await respuesta.json();

    const contenedor =
    document.getElementById("productos");

    contenedor.innerHTML = "";

    productos.forEach(producto=>{

        contenedor.innerHTML += `
        
        <div class="card">

            <img src="${producto.imagen}">

            <h3>${producto.nombre}</h3>

            <p>${producto.categoria}</p>

            <p>Q${producto.precio}</p>

            <button>
                Agregar al carrito
            </button>

        </div>
        `;
    });

}

cargarProductos();