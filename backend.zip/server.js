// =========================
// SERVER.JS COMPLETO
// =========================

const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const PDFDocument = require("pdfkit");
const fs = require("fs");

const app = express();

const PORT =
process.env.PORT || 3000;

const SECRET =
"SECRET_KEY_TECHNOVA";


// =========================
// CLAVE ADMIN REAL
// =========================

// PASSWORD REAL:
// 123456

const ADMIN_PASSWORD =
"123456";


// =========================
// MIDDLEWARES
// =========================

app.use(cors());

app.use(express.json());

app.use(
    "/facturas",
    express.static("facturas")
);


// =========================
// SQLITE
// =========================

const db =
new sqlite3.Database(
    "./database.db",
    (err)=>{

        if(err){

            console.log(err);

        }else{

            console.log(
                "SQLite conectado"
            );

        }

    }
);


// =========================
// TABLA USUARIOS
// =========================

db.run(`

CREATE TABLE IF NOT EXISTS usuarios(

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    nombre TEXT,

    correo TEXT UNIQUE,

    password TEXT,

    rol TEXT

)

`);


// =========================
// TABLA PRODUCTOS
// =========================

db.run(`

CREATE TABLE IF NOT EXISTS productos(

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    nombre TEXT,

    precio REAL,

    cantidad INTEGER,

    categoria TEXT,

    imagen TEXT

)

`);


// =========================
// TABLA COMPRAS
// =========================

db.run(`

CREATE TABLE IF NOT EXISTS compras(

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    usuario_id INTEGER,

    total REAL,

    fecha TEXT

)

`);


// =========================
// INSERTAR PRODUCTOS
// =========================

db.get(
    `
    SELECT COUNT(*) as total
    FROM productos
    `,
    [],

    (err,row)=>{

        if(row.total === 0){

            const productos = [

                ["Laptop ASUS ROG",9500,5,"Laptops","https://images.unsplash.com/photo-1517336714739-489689fd1ca8"],
                ["MacBook Pro",15000,3,"Laptops","https://images.unsplash.com/photo-1496181133206-80ce9b88a853"],
                ["HP Pavilion",7000,4,"Laptops","https://images.unsplash.com/photo-1498050108023-c5249f4df085"],
                ["Lenovo Legion",11000,6,"Laptops","https://images.unsplash.com/photo-1518770660439-4636190af475"],
                ["Acer Nitro",8500,7,"Laptops","https://images.unsplash.com/photo-1517430816045-df4b7de11d1d"],

                ["iPhone 15",12000,8,"Celulares","https://images.unsplash.com/photo-1511707171634-5f897ff02aa9"],
                ["Samsung S24",9800,10,"Celulares","https://images.unsplash.com/photo-1510557880182-3f8cbf4e1f1d"],
                ["Xiaomi Redmi Note",3200,12,"Celulares","https://images.unsplash.com/photo-1580910051074-3eb694886505"],
                ["Huawei P60",5600,9,"Celulares","https://images.unsplash.com/photo-1598327105666-5b89351aff97"],
                ["Motorola Edge",4800,7,"Celulares","https://images.unsplash.com/photo-1585060544812-6b45742d762f"],

                ["AirPods Pro",2200,10,"Audifonos","https://images.unsplash.com/photo-1588423771073-b8903fbb85b5"],
                ["Sony WH1000XM5",3400,5,"Audifonos","https://images.unsplash.com/photo-1505740420928-5e560c06d30e"],
                ["JBL Tune",850,15,"Audifonos","https://images.unsplash.com/photo-1484704849700-f032a568e944"],
                ["HyperX Cloud",1200,7,"Audifonos","https://images.unsplash.com/photo-1546435770-a3e426bf472b"],
                ["Razer Kraken",1400,8,"Audifonos","https://images.unsplash.com/photo-1518444065439-e933c06ce9cd"],

                ["Redragon K552",350,10,"Teclados","https://images.unsplash.com/photo-1511467687858-23d96c32e4ae"],
                ["Razer Huntsman",1200,5,"Teclados","https://images.unsplash.com/photo-1515879218367-8466d910aaa4"],
                ["Logitech G Pro",980,6,"Teclados","https://images.unsplash.com/photo-1517694712202-14dd9538aa97"],
                ["Corsair K70",1350,5,"Teclados","https://images.unsplash.com/photo-1516035069371-29a1b244cc32"],
                ["HyperX Alloy",800,7,"Teclados","https://images.unsplash.com/photo-1527443154391-507e9dc6c5cc"],

                ["Samsung Odyssey",3500,4,"Monitores","https://images.unsplash.com/photo-1527443224154-c4a3942d3acf"],
                ["LG UltraGear",2900,5,"Monitores","https://images.unsplash.com/photo-1527443154391-507e9dc6c5cc"],
                ["ASUS Gaming",3200,3,"Monitores","https://images.unsplash.com/photo-1498050108023-c5249f4df085"],
                ["Acer Predator",4100,2,"Monitores","https://images.unsplash.com/photo-1496171367470-9ed9a91ea931"],
                ["MSI Optix",2800,5,"Monitores","https://images.unsplash.com/photo-1517336714739-489689fd1ca8"],

                ["PlayStation 5",6500,5,"Consolas","https://images.unsplash.com/photo-1606813907291-d86efa9b94db"],
                ["Xbox Series X",6200,4,"Consolas","https://images.unsplash.com/photo-1621259182978-fbf93132d53d"],
                ["Nintendo Switch",2800,7,"Consolas","https://images.unsplash.com/photo-1578303512597-81e6cc155b3e"],
                ["Steam Deck",4200,3,"Consolas","https://images.unsplash.com/photo-1605902711622-cfb43c44367f"],
                ["PS5 Slim",7000,4,"Consolas","https://images.unsplash.com/photo-1486572788966-cfd3df1f5b42"]

            ];

            productos.forEach(producto=>{

                db.run(
                    `
                    INSERT INTO productos
                    (
                        nombre,
                        precio,
                        cantidad,
                        categoria,
                        imagen
                    )
                    VALUES(?,?,?,?,?)
                    `,
                    producto
                );

            });

            console.log(
                "Productos insertados"
            );

        }

    }
);


// =========================
// REGISTER
// =========================

app.post("/register",(req,res)=>{

    const {

        nombre,
        correo,
        password,
        rol,
        foto,
        claveAdmin

    } = req.body;


    // VALIDAR CAMPOS
    if(
        !nombre ||
        !correo ||
        !password ||
        !rol
    ){

        return res.status(400).json({

            mensaje:
            "Todos los campos son obligatorios"

        });

    }


    // =========================
    // VALIDAR ADMIN
    // =========================

    if(rol === "admin"){

        // SI NO ESCRIBE CLAVE
        if(!claveAdmin){

            return res.status(401).json({

                mensaje:
                "Debes ingresar clave admin"

            });

        }

        // VALIDAR CLAVE
        if(claveAdmin !== ADMIN_PASSWORD){

            return res.status(401).json({

                mensaje:
                "Clave admin incorrecta"

            });

        }

    }


    // ENCRIPTAR PASSWORD USUARIO
    const passwordHash =
    bcrypt.hashSync(password,10);


    // INSERTAR
    db.run(
        `
        INSERT INTO usuarios
         (
         nombre,
         correo,
         password,
         rol
         )
         VALUES(?,?,?,?) 
        `,
        [
         nombre,
         correo,
         passwordHash,
         rol
        ],

        function(err){

            if(err){

                return res.status(500).json({

                    error:err.message
                });

            }

            res.json({

                mensaje:
                "Usuario registrado"

            });

        }
    );

});


// =========================
// LOGIN
// =========================

app.post("/login",(req,res)=>{

    const {
        correo,
        password
    } = req.body;

    db.get(
        `
        SELECT * FROM usuarios
        WHERE correo = ?
        `,
        [correo],

        (err,usuario)=>{

            if(err){

                return res.status(500).json(err);

            }

            if(!usuario){

                return res.status(404).json({

                    mensaje:
                    "Usuario no encontrado"

                });

            }

            const validar =
            bcrypt.compareSync(

                password,
                usuario.password

            );

            if(!validar){

                return res.status(401).json({

                    mensaje:
                    "Contraseña incorrecta"

                });

            }

            const token =
            jwt.sign(

                {
                    id:usuario.id,
                    rol:usuario.rol
                },

                SECRET,

                {
                    expiresIn:"7d"
                }

            );

            res.json({

                token,

                usuario:{

                    id:usuario.id,
                    nombre:usuario.nombre,
                    correo:usuario.correo,
                    rol:usuario.rol,
                    foto:usuario.foto

                }

            });

        }
    );

});


// =========================
// PRODUCTOS
// =========================

app.get("/productos",(req,res)=>{

    db.all(
        `
        SELECT * FROM productos
        `,
        [],

        (err,productos)=>{

            if(err){

                return res.status(500).json(err);

            }

            res.json(productos);

        }
    );

});


// =========================
// AGREGAR PRODUCTO
// =========================

app.post("/productos",(req,res)=>{

    const {

        nombre,
        precio,
        cantidad,
        categoria,
        imagen

    } = req.body;

    // VALIDAR
    if(
        !nombre ||
        !precio ||
        !cantidad ||
        !categoria
    ){

        return res.status(400).json({

            mensaje:
            "Completa todos los campos"

        });

    }

    db.run(
        `
        INSERT INTO productos
        (
            nombre,
            precio,
            cantidad,
            categoria,
            imagen
        )
        VALUES(?,?,?,?,?)
        `,
        [

            nombre,
            precio,
            cantidad,
            categoria,
            imagen || ""

        ],

        function(err){

            if(err){

                return res.status(500).json({

                    error:err.message
                });

            }

            res.json({

                mensaje:
                "Producto agregado"

            });

        }
    );

});

// =========================
// AGREGAR PRODUCTO
// =========================

app.post("/productos",(req,res)=>{

    const {

    nombre,
    correo,
    password,
    rol,
    claveAdmin

} = req.body;

    db.run(
        `
        INSERT INTO productos
        (
            nombre,
            precio,
            cantidad,
            categoria,
            imagen
        )
        VALUES(?,?,?,?,?)
        `,
        [

            nombre,
            precio,
            cantidad,
            categoria,
            imagen

        ],

        function(err){

            if(err){

                return res.status(500).json(err);

            }

            res.json({

                mensaje:
                "Producto agregado"

            });

        }
    );

});


// =========================
// ELIMINAR PRODUCTO
// =========================

app.delete("/productos/:id",(req,res)=>{

    const {id} =
    req.params;

    db.run(
        `
        DELETE FROM productos
        WHERE id = ?
        `,
        [id],

        function(err){

            if(err){

                return res.status(500).json(err);

            }

            res.json({

                mensaje:
                "Producto eliminado"

            });

        }
    );

});


// =========================
// COMPRAS
// =========================

app.post("/compras",(req,res)=>{

    const {

        usuario_id,
        total,
        fecha

    } = req.body;

    db.run(
        `
        INSERT INTO compras
        (
            usuario_id,
            total,
            fecha
        )
        VALUES(?,?,?)
        `,
        [

            usuario_id,
            total,
            fecha

        ],

        function(err){

            if(err){

                return res.status(500).json(err);

            }

            res.json({

                mensaje:
                "Compra guardada"

            });

        }
    );

});


// =========================
// HISTORIAL
// =========================

app.get("/compras/:usuario_id",(req,res)=>{

    const {usuario_id} =
    req.params;

    db.all(
        `
        SELECT * FROM compras
        WHERE usuario_id = ?
        ORDER BY id DESC
        `,
        [usuario_id],

        (err,compras)=>{

            if(err){

                return res.status(500).json(err);

            }

            res.json(compras);

        }
    );

});


// =========================
// ESTADISTICAS
// =========================

app.get("/estadisticas",(req,res)=>{

    db.get(
        `
        SELECT
        SUM(total) as ventas
        FROM compras
        `,
        [],

        (err,ventas)=>{

            db.get(
                `
                SELECT
                COUNT(*) as usuarios
                FROM usuarios
                `,
                [],

                (err2,usuarios)=>{

                    res.json({

                        ventas:
                        ventas.ventas || 0,

                        usuarios:
                        usuarios.usuarios || 0

                    });

                }
            );

        }
    );

});


// =========================
// SERVIDOR
// =========================

app.listen(PORT,()=>{

    console.log(

        `Servidor corriendo en puerto ${PORT}`

    );

});